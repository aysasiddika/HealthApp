package com.aysasiddika.Health.BroadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aysasiddika.Health.Database1.DrinkDataSource;
import com.aysasiddika.Health.MainWindow.AlarmHelper;
import com.aysasiddika.Health.Settings.PrefsHelper;


public class BootBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context pContext, Intent intent) {
        DrinkDataSource db= new DrinkDataSource(pContext);
        db.open();
        int waterNeed= PrefsHelper.getWaterNeedPrefs(pContext);
        db.createMissingDateLog(0,waterNeed);
        AlarmHelper.setDBAlarm(pContext);
    }
}


