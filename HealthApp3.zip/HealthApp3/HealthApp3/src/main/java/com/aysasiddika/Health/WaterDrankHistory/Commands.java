package com.aysasiddika.Health.WaterDrankHistory;

/**
 * Created by Abeer on 4/16/2017.
 */

public class Commands {
    public static String DateLogItem= "date_log_item";
}